import React from 'react';
import '../styles/footer.css';

const Footer = () => (
  <footer>
    <p>&copy; 2025 City Hospital. All Rights Reserved.</p>
  </footer>
);

export default Footer;
